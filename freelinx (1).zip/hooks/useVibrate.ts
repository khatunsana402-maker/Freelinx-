
'use client';

import { useCallback } from 'react';

/**
 * A simple hook to provide haptic feedback (vibration) on mobile devices.
 * @param pattern - The vibration pattern (e.g., [100, 200, 100]). Defaults to a single short vibration.
 * @returns A function to trigger the vibration.
 */
export const useVibrate = (pattern: VibratePattern = 50) => {
  const vibrate = useCallback(() => {
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch (error) {
        console.warn("Vibration failed. User may have disabled it.", error);
      }
    }
  }, [pattern]);

  return vibrate;
};
