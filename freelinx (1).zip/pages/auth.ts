

import NextAuth from 'next-auth';
// FIX: Update to NextAuth v5 type 'NextAuthConfig'.
import type { NextAuthConfig } from 'next-auth';
import { PrismaAdapter } from '@auth/prisma-adapter';
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import { prisma } from './prisma';
import GoogleProvider from 'next-auth/providers/google';
import EmailProvider from 'next-auth/providers/email';
// FIX: The 'Adapter' type from 'next-auth/adapters' is deprecated in NextAuth v5.
// import { Adapter } from 'next-auth/adapters';
// FIX: Use the edge-compatible Prisma client import.
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import { UserRole } from '@prisma/client';

export const authOptions: NextAuthConfig = {
  // FIX: Remove the deprecated 'as Adapter' cast. The adapter handles its own type.
  adapter: PrismaAdapter(prisma),
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
    EmailProvider({
      server: process.env.EMAIL_SERVER,
      from: process.env.EMAIL_FROM,
    }),
  ],
  session: {
    strategy: 'jwt',
  },
  callbacks: {
    async session({ session, token }) {
      if (token.sub && session.user) {
        session.user.id = token.sub;
        session.user.role = token.role as UserRole;
      }
      return session;
    },
    async jwt({ token }) {
      if (!token.sub) return token;

      const existingUser = await prisma.user.findUnique({
        where: { id: token.sub },
      });

      if (!existingUser) return token;
      
      token.role = existingUser.role;
      return token;
    },
  },
  events: {
    async createUser({ user }) {
      if (user.email && user.email === process.env.ADMIN_EMAIL) {
        await prisma.user.update({
          where: { id: user.id! },
          data: { role: UserRole.ADMIN },
        });
      }
    },
  },
  pages: {
    signIn: '/auth/signin',
    verifyRequest: '/auth/verify-request',
    error: '/auth/signin', // Redirect to signin page on error
  },
};

// FIX: Update to NextAuth v5 syntax
const { handlers, auth } = NextAuth(authOptions);
export const { GET, POST } = handlers;

export const getAuthSession = auth;
