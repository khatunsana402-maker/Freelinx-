
import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { prisma } from '../../../../lib/prisma';
import { razorpay } from '../../../../lib/razorpay';

export async function POST(req: NextRequest) {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET!;

  try {
    const text = await req.text();
    const signature = req.headers.get('x-razorpay-signature');

    if (!signature) {
        return NextResponse.json({ error: 'Signature missing' }, { status: 400 });
    }

    const shasum = crypto.createHmac('sha256', secret);
    shasum.update(text);
    const digest = shasum.digest('hex');

    if (digest !== signature) {
      return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
    }

    const body = JSON.parse(text);

    if (body.event === 'order.paid') {
      const { order_id, id: payment_id } = body.payload.payment.entity;

      const order = await prisma.order.findUnique({
          where: { paymentId: order_id }
      });

      if (order && !order.isPaid) {
          await prisma.$transaction(async (tx) => {
              await tx.order.update({
                  where: { id: order.id },
                  data: {
                      isPaid: true,
                      status: 'IN_PROGRESS' // Or keep as is, depending on flow
                  }
              });

              await tx.transaction.create({
                  data: {
                      amount: order.totalPrice,
                      type: 'DEBIT',
                      userId: order.clientId,
                      orderId: order.id,
                      razorpayPaymentId: payment_id,
                  }
              });
          });
      }
    }

    return NextResponse.json({ status: 'ok' });
  } catch (error: any) {
    console.error('Webhook error:', error);
    return NextResponse.json({ error: 'Webhook handler failed' }, { status: 500 });
  }
}
