

'use client';
import React from 'react';
// FIX: Use 'import type' for types and a separate import for enum values.
// FIX: Use the edge-compatible Prisma client import.
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import type { User } from '@prisma/client';
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import { UserRole } from '@prisma/client';
// FIX: Correct the relative import path for the Button component.
import Button from '../../../../components/ui/Button';
// FIX: Correct the relative import path for server actions.
import { updateUserRole, toggleUserVerification, toggleUserSuspension } from '../../../../lib/actions/admin.actions';

interface UserActionsProps {
  user: User;
}

const UserActions: React.FC<UserActionsProps> = ({ user }) => {

  return (
    <div className="flex items-center justify-end gap-2">
      <form action={updateUserRole} className="flex items-center gap-2">
        <input type="hidden" name="userId" value={user.id} />
        <select
          name="role"
          defaultValue={user.role as string}
          className="px-3 py-2 border rounded-md bg-input text-foreground focus:ring-ring focus:ring-1 focus:outline-none text-xs h-9"
        >
          {Object.values(UserRole).map((role) => (
            <option key={role as string} value={role as string}>{role as string}</option>
          ))}
        </select>
        <Button size="sm" type="submit">Set Role</Button>
      </form>
      {user.role === 'CREATOR' && (
        <form action={toggleUserVerification}>
            <input type="hidden" name="userId" value={user.id} />
            <Button size="sm" variant="outline" type="submit">
                {user.isVerifiedCreator ? 'Unverify' : 'Verify'}
            </Button>
        </form>
      )}
      <form action={toggleUserSuspension}>
        <input type="hidden" name="userId" value={user.id} />
        <Button size="sm" variant="destructive" type="submit">
            {user.isSuspended ? 'Unsuspend' : 'Suspend'}
        </Button>
      </form>
    </div>
  );
};

export default UserActions;
