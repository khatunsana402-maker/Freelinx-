
import { GoogleGenAI } from '@google/genai';

export const runtime = 'edge';

interface ChatMessage {
    role: 'user' | 'model';
    content: string;
}

export async function POST(req: Request) {
  try {
    const { prompt, history } = await req.json();

    if (!prompt) {
      return new Response(JSON.stringify({ error: 'Prompt is required' }), { status: 400 });
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    
    // Format history for the Gemini API
    const formattedHistory = (history as ChatMessage[]).map(msg => ({
      role: msg.role,
      parts: [{ text: msg.content }]
    }));

    const chat = ai.chats.create({ 
        model: 'gemini-2.5-pro',
        history: formattedHistory,
        config: {
            systemInstruction: "You are 'Freelinx AI', a helpful assistant for a freelancing marketplace. Your goal is to assist both clients and creators. For clients, you can help write project briefs or suggest types of creators. For creators, you can help with writing proposals or brainstorming ideas. Be concise, helpful, and friendly. Format responses with markdown where appropriate.",
        }
    });

    const response = await chat.sendMessageStream({ message: prompt });

    const stream = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder();
        for await (const chunk of response) {
          controller.enqueue(encoder.encode(chunk.text));
        }
        controller.close();
      },
    });

    return new Response(stream, {
        headers: {
            'Content-Type': 'text/plain; charset=utf-8',
            'Connection': 'keep-alive',
            'Cache-Control': 'no-cache',
        }
    });

  } catch (error) {
    console.error('Error in AI chat generation:', error);
    return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
  }
}
