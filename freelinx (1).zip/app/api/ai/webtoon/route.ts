
import { GoogleGenAI, Type } from "@google/genai";

export async function POST(req: Request) {
    try {
        const { premise, genre, characters } = await req.json();

        if (!premise || !genre || !characters) {
            return new Response(JSON.stringify({ error: 'Premise, genre, and characters are required' }), { status: 400 });
        }

        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Generate a webtoon outline for the first 3-5 scenes of a story.
            - Genre: ${genre}
            - Premise: ${premise}
            - Main Characters: ${characters}
            
            Provide a title for the story, a one-sentence logline, and a list of scenes. Each scene must have a title, a setting, and a list of key events.
            `,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        title: { type: Type.STRING },
                        logline: { type: Type.STRING },
                        scenes: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    scene: { type: Type.INTEGER },
                                    title: { type: Type.STRING },
                                    setting: { type: Type.STRING },
                                    events: {
                                        type: Type.ARRAY,
                                        items: { type: Type.STRING }
                                    }
                                },
                                required: ["scene", "title", "setting", "events"]
                            }
                        }
                    },
                    required: ["title", "logline", "scenes"]
                },
            },
        });

        const jsonText = response.text.trim();
        const outline = JSON.parse(jsonText);
        
        return new Response(JSON.stringify(outline), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Error in AI webtoon generation:', error);
        return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
    }
}
