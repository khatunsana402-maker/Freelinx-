import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/Card';

export default function TermsPage() {
  return (
    <div className="max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Terms of Service</CardTitle>
        </CardHeader>
        <CardContent className="prose dark:prose-invert">
          <h2>1. Introduction</h2>
          <p>Welcome to Freelinx. These are our terms and conditions for use of the service, which you may access in several ways, including but not limited to the World Wide Web via freelinx.app, digital television, PDA, mobile phone and RSS feeds. In these terms and conditions, when we say "Freelinx Site" we mean the digital information network operated by or on behalf of Freelinx, Inc. or its parent companies, subsidiaries and affiliates, regardless of how you access the network, as well as any Freelinx apps whether now known or hereafter developed.</p>
          
          <h2>2. Use of this Site</h2>
          <p>By using the Freelinx Site, you agree to be bound by these terms and conditions. If you do not agree to be bound by all of the following terms please do not access, use and/or contribute to the Freelinx Site.</p>

          <h2>3. Content</h2>
          <p>All intellectual property rights, including copyright, in the content accessible (or available for download) on the Freelinx Site, including text, pictures, graphics, video, and audio material ("Content") are owned by Freelinx or its licensors. You may not use this Content for any other purpose, including any commercial purpose, without our prior written permission.</p>

          <p><em>[This is placeholder text. A complete Terms of Service document is required for a production application.]</em></p>
        </CardContent>
      </Card>
    </div>
  );
}