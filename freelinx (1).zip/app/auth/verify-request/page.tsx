
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../../components/ui/Card';

const VerifyRequestPage = () => {
  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-20rem)]">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Check your email</CardTitle>
          <CardDescription>A sign-in link has been sent to your email address.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-center text-sm text-muted-foreground">
            Please follow the link in the email to complete your sign-in process.
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default VerifyRequestPage;
