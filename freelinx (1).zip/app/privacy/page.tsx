import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/Card';

export default function PrivacyPage() {
  return (
    <div className="max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Privacy Policy</CardTitle>
        </CardHeader>
        <CardContent className="prose dark:prose-invert">
          <h2>1. Information We Collect</h2>
          <p>We collect information about you when you register for an account, create or modify your profile, set preferences, sign-up for or make purchases through the Services. This includes your name, email address, and any other information you choose to provide.</p>

          <h2>2. How We Use Information</h2>
          <p>We use the information we collect to provide, maintain, and improve our services. We also use the information to communicate with you, including to send you transaction confirmations, invoices, technical notices, updates, security alerts, and support messages.</p>
          
          <h2>3. Sharing Information</h2>
          <p>We do not share your personal information with third parties except as described in this privacy policy. We may share your personal information with your consent, to comply with laws, to provide you with services, to protect your rights, or to fulfill business obligations.</p>

          <p><em>[This is placeholder text. A complete Privacy Policy is required for a production application.]</em></p>
        </CardContent>
      </Card>
    </div>
  );
}