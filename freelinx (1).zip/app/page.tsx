import React from 'react';
import Button from '../components/ui/Button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/Card';

const HomePage: React.FC = () => {
  return (
    <div className="space-y-16 py-8">
      <section className="text-center">
        <h1 className="text-4xl md:text-6xl font-bold tracking-tighter mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
          Where Talent Meets AI.
        </h1>
        <p className="max-w-2xl mx-auto text-lg text-muted-foreground mb-8">
          Freelinx is the premier marketplace for creative talent, supercharged with powerful AI tools to bring your vision to life, faster.
        </p>
        <div className="space-x-4">
          <Button size="lg" href="/explore">Explore Creators</Button>
          <Button size="lg" variant="outline" href="/tools">Use Free AI Tools</Button>
        </div>
      </section>

      <section>
        <h2 className="text-3xl font-bold text-center mb-8">Featured Services</h2>
        <div className="grid md:grid-cols-3 gap-8">
            <Card>
                <CardHeader>
                    <CardTitle>Webtoon Art</CardTitle>
                    <CardDescription>Bring your stories to life with stunning visuals.</CardDescription>
                </CardHeader>
                <CardContent>
                    <p>Find talented artists who can create captivating webtoon panels, characters, and backgrounds for your series.</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader>
                    <CardTitle>Script Writing</CardTitle>
                    <CardDescription>Craft compelling narratives that hook your audience.</CardDescription>
                </CardHeader>
                <CardContent>
                    <p>Hire professional writers to create, edit, or proofread scripts for your short films, series, or games.</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader>
                    <CardTitle>AI-Powered Tools</CardTitle>
                    <CardDescription>Supercharge your creative process for free.</CardDescription>
                </CardHeader>
                <CardContent>
                    <p>Use our AI script generator and webtoon concept artist to quickly prototype ideas and overcome creative blocks.</p>
                </CardContent>
            </Card>
        </div>
      </section>
    </div>
  );
};


export default function Home() {
  return <HomePage />;
}