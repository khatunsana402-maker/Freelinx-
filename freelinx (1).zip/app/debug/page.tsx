'use client';
import React, { useState, useEffect } from 'react';
import { errors, clearErrors } from '../../lib/errorStore';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../../components/ui/Card';
import Button from '../../components/ui/Button';

const DebugPage = () => {
    const [clientErrors, setClientErrors] = useState([...errors]);

    useEffect(() => {
        const interval = setInterval(() => {
            if (errors.length !== clientErrors.length) {
                setClientErrors([...errors]);
            }
        }, 1000);
        return () => clearInterval(interval);
    }, [clientErrors.length]);
    
    const handleClear = () => {
        clearErrors();
        setClientErrors([]);
    };

    const routes = [
        '/', '/explore', '/services', '/tools', '/about', '/contact',
        '/admin', '/admin/users', '/dashboard', '/creator', '/debug', '/health'
    ];

    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <h1 className="text-3xl font-bold">Debug Information</h1>

            <Card>
                <CardHeader>
                    <CardTitle>Environment Toggles</CardTitle>
                </CardHeader>
                <CardContent>
                    <ul>
                        <li>
                            <strong>Preview-Safe Mode:</strong> 
                            <span className={process.env.NEXT_PUBLIC_PREVIEW_SAFE === 'true' ? 'text-green-500' : 'text-red-500'}>
                                {process.env.NEXT_PUBLIC_PREVIEW_SAFE === 'true' ? 'ON' : 'OFF'}
                            </span>
                        </li>
                    </ul>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Application Routes</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                    {routes.map(route => (
                        <code key={route} className="px-2 py-1 bg-muted rounded-md text-sm">{route}</code>
                    ))}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <div>
                            <CardTitle>Recent Client-Side Errors</CardTitle>
                            <CardDescription>Errors captured by the global error boundary.</CardDescription>
                        </div>
                        <Button variant="destructive" size="sm" onClick={handleClear} disabled={clientErrors.length === 0}>Clear Errors</Button>
                    </div>
                </CardHeader>
                <CardContent>
                    {clientErrors.length > 0 ? (
                        <div className="space-y-4">
                            {clientErrors.map((e, i) => (
                                <details key={i} className="bg-muted/50 p-3 rounded-md text-xs">
                                    <summary className="font-mono cursor-pointer">{e.error.message}</summary>
                                    <pre className="mt-2 p-2 bg-background rounded overflow-auto">
                                        <strong>Stack Trace:</strong><br />
                                        {e.error.stack}
                                        <br /><br />
                                        <strong>Component Stack:</strong><br />
                                        {e.errorInfo.componentStack}
                                    </pre>
                                </details>
                            ))}
                        </div>
                    ) : (
                        <p className="text-muted-foreground text-sm">No client-side errors have been captured.</p>
                    )}
                </CardContent>
            </Card>
        </div>
    );
};

export default DebugPage;
