
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../../components/ui/Card';
import { getAuthSession } from '../../../lib/auth';
import { prisma } from '../../../lib/prisma';
// FIX: Use the edge-compatible Prisma client import.
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import { UserRole, OrderStatus } from '@prisma/client';
import { getMockAdminDashboardData } from '../../../lib/mock-data';

interface AdminDashboardData {
    userCount: number;
    openProjectsCount: number;
    completedOrdersCount: number;
    totalRevenue: { _sum: { amount: number | null } };
    topCreators: { name: string | null; walletBalance: number }[];
    userCounts: { [key in UserRole]: number };
}

const AdminDashboardContent: React.FC<{ data: AdminDashboardData, session: any }> = ({ data, session }) => {
    const { userCount, openProjectsCount, completedOrdersCount, totalRevenue, topCreators, userCounts } = data;
    return (
        <div className="space-y-8">
            <div>
                <h1 className="text-3xl font-bold">Admin Dashboard</h1>
                <p className="text-muted-foreground">Site-wide management and overview. Welcome, {session?.user?.name}.</p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                    <CardHeader><CardTitle>Total Revenue</CardTitle></CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold">₹{totalRevenue._sum.amount?.toFixed(2) ?? '0.00'}</p>
                        <p className="text-xs text-muted-foreground">From all completed transactions</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle>Total Users</CardTitle></CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold">{userCount}</p>
                        <p className="text-xs text-muted-foreground">
                            {userCounts[UserRole.CLIENT]} Clients, {userCounts[UserRole.CREATOR]} Creators
                        </p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle>Open Projects</CardTitle></CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold">{openProjectsCount}</p>
                        <p className="text-xs text-muted-foreground">Projects awaiting proposals</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader><CardTitle>Completed Orders</CardTitle></CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold">{completedOrdersCount}</p>
                         <p className="text-xs text-muted-foreground">Successfully delivered projects</p>
                    </CardContent>
                </Card>
            </div>
            
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Platform Administration</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-muted-foreground">Use the sidebar to manage users, projects, and site settings.</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Top Creators</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ul className="space-y-2">
                            {topCreators.map(creator => (
                                <li key={creator.name} className="flex justify-between items-center text-sm">
                                    <span>{creator.name}</span>
                                    <span className="font-mono text-muted-foreground">₹{creator.walletBalance.toFixed(2)} earned</span>
                                </li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>
             </div>
        </div>
    );
};


const AdminDashboardPage = async () => {
    const session = await getAuthSession();

    if (process.env.NEXT_PUBLIC_PREVIEW_SAFE === 'true') {
        const mockData = getMockAdminDashboardData();
        return <AdminDashboardContent data={mockData} session={session} />;
    }
    
    const userCount = await prisma.user.count();
    const openProjectsCount = await prisma.project.count({ where: { status: 'OPEN' } });
    const completedOrdersCount = await prisma.order.count({ where: { status: 'COMPLETED' } });
    
    const totalRevenue = await prisma.transaction.aggregate({
        _sum: {
            amount: true,
        },
        where: {
            type: 'DEBIT',
        },
    });

    const topCreators = await prisma.user.findMany({
        where: { role: UserRole.CREATOR },
        take: 3,
        orderBy: {
            walletBalance: 'desc',
        },
        select: {
            name: true,
            walletBalance: true,
        }
    });

    const totalUsers = await prisma.user.groupBy({
        by: ['role'],
        _count: {
            role: true,
        },
    });

    const userCounts = {
        [UserRole.CLIENT]: totalUsers.find(u => u.role === UserRole.CLIENT)?._count.role ?? 0,
        [UserRole.CREATOR]: totalUsers.find(u => u.role === UserRole.CREATOR)?._count.role ?? 0,
        [UserRole.ADMIN]: totalUsers.find(u => u.role === UserRole.ADMIN)?._count.role ?? 0,
    }

    const data = { userCount, openProjectsCount, completedOrdersCount, totalRevenue, topCreators, userCounts };

    return <AdminDashboardContent data={data} session={session} />;
};

export default AdminDashboardPage;
