import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../../../../components/ui/Card';
import { prisma } from '../../../../lib/prisma';
import UserActions from '../../../../components/admin/UserActions';
import { getMockUsers } from '../../../../lib/mock-data';

async function AdminUsersPage() {
  const users = process.env.NEXT_PUBLIC_PREVIEW_SAFE === 'true'
    ? getMockUsers()
    : await prisma.user.findMany({
        orderBy: { createdAt: 'desc' },
      });

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Manage Users</h1>
      <Card>
        <CardHeader>
          <CardTitle>All Users</CardTitle>
          <CardDescription>View and manage roles and status for all registered users on the platform.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr>
                  <th className="p-2">Name</th>
                  <th className="p-2">Email</th>
                  <th className="p-2">Role & Status</th>
                  <th className="p-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id} className="border-t">
                    <td className="p-2 font-medium">{user.name}</td>
                    <td className="p-2">{user.email}</td>
                    <td className="p-2">
                      <div className="flex flex-col">
                        <span>{user.role}</span>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          {user.isVerifiedCreator && <span className="px-2 py-0.5 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 rounded-full">Verified</span>}
                          {user.isSuspended && <span className="px-2 py-0.5 bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300 rounded-full">Suspended</span>}
                        </div>
                      </div>
                    </td>
                    <td className="p-2">
                      <UserActions user={user} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default AdminUsersPage;
