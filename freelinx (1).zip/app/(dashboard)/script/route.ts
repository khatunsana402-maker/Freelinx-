
import { GoogleGenAI } from '@google/genai';

export const runtime = 'edge';

export async function POST(req: Request) {
  try {
    const { prompt, genre } = await req.json();

    if (!prompt || !genre) {
      return new Response(JSON.stringify({ error: 'Prompt and genre are required' }), { status: 400 });
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const stream = await ai.models.generateContentStream({
        model: 'gemini-2.5-pro',
        contents: `Generate a short script scene. The scene should be in the ${genre} genre. The prompt is: "${prompt}". Format it clearly with character names in uppercase followed by their dialogue. Include brief action lines or scene descriptions in parentheses.`,
    });

    const readableStream = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder();
        for await (const chunk of stream) {
          const text = chunk.text;
          if (text) {
             controller.enqueue(encoder.encode(`data: ${JSON.stringify(text)}\n\n`));
          }
        }
        controller.close();
      },
    });

    return new Response(readableStream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });

  } catch (error) {
    console.error('Error in AI script generation:', error);
    return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
  }
}
