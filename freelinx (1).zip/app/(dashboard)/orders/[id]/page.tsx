

import React from 'react';
import { getAuthSession } from '../../../../lib/auth';
import { prisma } from '../../../../lib/prisma';
import { notFound } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '../../../../components/ui/Card';
import PaymentButton from '../../../../components/payment/PaymentButton';

export default async function OrderDetailsPage({ params }: { params: { id: string } }) {
  const session = await getAuthSession();
  const orderId = params.id;

  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: {
      project: true,
      client: true,
      creator: true,
    },
  });

  if (!order) {
    notFound();
  }
  
  const isClient = session?.user?.id === order.clientId;

  return (
    <div className="max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Order Details</CardTitle>
          <CardDescription>Order for project: "{order.project.title}"</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Status</p>
              <p className="font-semibold">{order.status}</p>
            </div>
             <div>
              <p className="text-muted-foreground">Payment Status</p>
              <p className={`font-semibold ${order.isPaid ? 'text-green-600' : 'text-orange-600'}`}>
                {order.isPaid ? 'Paid' : 'Pending Payment'}
              </p>
            </div>
             <div>
              <p className="text-muted-foreground">Creator</p>
              <p>{order.creator.name}</p>
            </div>
             <div>
              <p className="text-muted-foreground">Client</p>
              <p>{order.client.name}</p>
            </div>
          </div>
          <div className="pt-4 border-t">
              <p className="text-muted-foreground">Total Price</p>
              <p className="text-2xl font-bold">₹{order.totalPrice.toFixed(2)}</p>
          </div>
        </CardContent>
        {isClient && !order.isPaid && (
          <CardFooter>
            <PaymentButton order={order} />
          </CardFooter>
        )}
      </Card>
    </div>
  );
}
