'use client';
import React, { useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { sendContactMessage } from '../../lib/actions/contact.actions';
import { useToast } from '../../components/ui/use-toast';

export default function ContactPage() {
    const { toast } = useToast();
    const formRef = useRef<HTMLFormElement>(null);

    const handleSubmit = async (formData: FormData) => {
        const result = await sendContactMessage(formData);
        
        if (result.success) {
            toast({
                title: "Message Sent!",
                description: "Thanks for reaching out. We'll get back to you shortly.",
            });
            formRef.current?.reset();
        } else {
            toast({
                title: "Error",
                description: result.error || "Failed to send message. Please try again.",
                variant: "destructive",
            });
        }
    };

    return (
        <div className="max-w-2xl mx-auto">
            <Card>
                <CardHeader className="text-center">
                    <CardTitle className="text-3xl">Contact Us</CardTitle>
                    <CardDescription>Have a question or feedback? We'd love to hear from you.</CardDescription>
                </CardHeader>
                <CardContent>
                    <form ref={formRef} action={handleSubmit} className="space-y-4">
                        <div className="space-y-2">
                            <label htmlFor="name" className="font-medium">Name</label>
                            <input id="name" name="name" required className="w-full p-2 border rounded-md bg-input" />
                        </div>
                        <div className="space-y-2">
                            <label htmlFor="email" className="font-medium">Email</label>
                            <input type="email" id="email" name="email" required className="w-full p-2 border rounded-md bg-input" />
                        </div>
                        <div className="space-y-2">
                            <label htmlFor="message" className="font-medium">Message</label>
                            <textarea id="message" name="message" required rows={5} className="w-full min-h-[120px] p-2 border rounded-md bg-input" />
                        </div>
                        <Button type="submit" className="w-full">Send Message</Button>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}