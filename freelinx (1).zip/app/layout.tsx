import React from 'react';
import './globals.css';
import { Providers } from './providers';
import Layout from '../components/layout/Layout';
import { Toaster } from '../components/ui/Toaster';
import Chatbot from '../components/chatbot/Chatbot';
import DevErrorOverlay from '../components/DevErrorOverlay';
import { SafeModeBadge } from '../components/ui/SafeModeBadge';

export const metadata = {
  title: 'Freelinx — Smart Freelancing & AI Tools',
  description: 'Freelinx helps creators and clients collaborate, hire, and create smarter with AI-powered tools for webtoons and scripts.',
  openGraph: {
    title: 'Freelinx — Smart Freelancing & AI Tools',
    description: 'The marketplace for creative talent, supercharged with free AI utilities.',
    type: 'website',
    locale: 'en_US',
    url: 'https://freelinx.vercel.app', // Replace with actual production URL
    siteName: 'Freelinx',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Freelinx — Smart Freelancing & AI Tools',
    description: 'The marketplace for creative talent, supercharged with free AI utilities.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* PWA Meta Tags for Mobile App Experience */}
        <meta name="application-name" content="Freelinx" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="Freelinx" />
        <meta name="format-detection" content="telephone=no" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="theme-color" content="#4f46e5" />
        
        {/*
          NOTE: A manifest.json file should be created in the `public` folder.
          This environment doesn't support file creation in `/public`, but if it did,
          the link below would enable the PWA manifest.
        */}
        {/* <link rel="manifest" href="/manifest.json" /> */}

        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        {/* Placeholder for Analytics Snippet (e.g., Google Analytics, PostHog) */}
      </head>
      <body>
        <Providers>
          <DevErrorOverlay>
            <Layout>
              {children}
            </Layout>
            <Chatbot />
            <Toaster />
            <SafeModeBadge />
          </DevErrorOverlay>
        </Providers>
      </body>
    </html>
  );
}
