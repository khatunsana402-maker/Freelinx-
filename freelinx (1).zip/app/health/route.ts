import { NextResponse } from 'next/server';

export const runtime = 'edge';

export async function GET() {
    const isDemo = process.env.NEXT_PUBLIC_PREVIEW_SAFE === 'true';
    return NextResponse.json({
        ok: true,
        time: new Date().toISOString(),
        demo: isDemo,
    });
}
