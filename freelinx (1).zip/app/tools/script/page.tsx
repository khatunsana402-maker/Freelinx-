
'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../../components/ui/Card';
import Button from '../../../components/ui/Button';

const genres = ["Sci-Fi", "Fantasy", "Comedy", "Drama", "Thriller", "Romance", "Action"];

const ScriptGeneratorPage = () => {
    const [prompt, setPrompt] = useState('');
    const [genre, setGenre] = useState(genres[0]);
    const [generatedScript, setGeneratedScript] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const { data: session } = useSession();
    
    const scriptEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        scriptEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [generatedScript]);

    const handleGenerate = async () => {
        if (!prompt) {
            setError('Please enter a prompt.');
            return;
        }
        setIsLoading(true);
        setError('');
        setGeneratedScript('');

        try {
            const response = await fetch('/api/ai/script', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt, genre }),
            });

            if (!response.body) {
              throw new Error("Response body is null");
            }

            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                const chunk = decoder.decode(value);
                const lines = chunk.split('\\n');
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        const data = line.substring(6);
                         try {
                           const parsed = JSON.parse(data);
                           setGeneratedScript(prev => prev + parsed);
                         } catch (e) {
                             // The final chunk might not be valid JSON, but still part of the stream
                             setGeneratedScript(prev => prev + data);
                         }
                    }
                }
            }

        } catch (err) {
            console.error(err);
            setError('Failed to generate script. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div className="text-center">
                <h1 className="text-4xl font-bold">AI Script Generator</h1>
                <p className="text-muted-foreground mt-2">Enter a prompt and genre to generate a script scene.</p>
            </div>
            <Card>
                <CardContent className="p-6">
                    <div className="grid gap-4">
                        <div className="space-y-2">
                            <label htmlFor="prompt" className="font-medium">Prompt</label>
                            <textarea
                                id="prompt"
                                placeholder="e.g., A detective discovers a clue on a rainy night."
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                className="w-full min-h-[100px] p-2 border rounded-md bg-background"
                            />
                        </div>
                        <div className="space-y-2">
                            <label htmlFor="genre" className="font-medium">Genre</label>
                            <select
                                id="genre"
                                value={genre}
                                onChange={(e) => setGenre(e.target.value)}
                                className="w-full p-2 border rounded-md bg-background"
                            >
                                {genres.map(g => <option key={g} value={g}>{g}</option>)}
                            </select>
                        </div>
                         {error && <p className="text-destructive text-sm">{error}</p>}
                        <Button onClick={handleGenerate} disabled={isLoading}>
                            {isLoading ? 'Generating...' : 'Generate Script'}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {generatedScript && (
                <Card>
                    <CardHeader>
                        <CardTitle>Generated Script</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="bg-muted/50 p-4 rounded-md whitespace-pre-wrap font-mono text-sm max-h-[500px] overflow-y-auto">
                            {generatedScript}
                             <div ref={scriptEndRef} />
                        </div>
                        {session?.user && (
                            <Button className="mt-4" disabled>Save Script (Coming Soon)</Button>
                        )}
                    </CardContent>
                </Card>
            )}
        </div>
    );
};

export default ScriptGeneratorPage;
