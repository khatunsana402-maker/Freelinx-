
'use client';

import React, { useState } from 'react';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../../components/ui/Card';
import Button from '../../../components/ui/Button';

interface Scene {
  scene: number;
  title: string;
  setting: string;
  events: string[];
}

interface WebtoonOutline {
  title: string;
  logline: string;
  scenes: Scene[];
}

const WebtoonToolPage = () => {
    const [premise, setPremise] = useState('');
    const [genre, setGenre] = useState('Fantasy');
    const [characters, setCharacters] = useState('');
    const [outline, setOutline] = useState<WebtoonOutline | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const { data: session } = useSession();

    const handleGenerate = async () => {
        if (!premise || !genre || !characters) {
            setError('Please fill in all fields.');
            return;
        }
        setIsLoading(true);
        setError('');
        setOutline(null);

        try {
            const response = await fetch('/api/ai/webtoon', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ premise, genre, characters }),
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to generate outline.');
            }

            const data = await response.json();
            setOutline(data);
        } catch (err: any) {
            console.error(err);
            setError(err.message || 'An unexpected error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div className="text-center">
                <h1 className="text-4xl font-bold">AI Webtoon Outliner</h1>
                <p className="text-muted-foreground mt-2">Describe your story to generate a multi-scene outline.</p>
            </div>
            <Card>
                <CardContent className="p-6">
                    <div className="grid gap-4">
                        <div>
                            <label htmlFor="premise" className="font-medium">Premise</label>
                            <textarea id="premise" placeholder="A magical librarian must find a missing book before it unravels reality." value={premise} onChange={(e) => setPremise(e.target.value)} className="w-full min-h-[100px] p-2 border rounded-md bg-background" />
                        </div>
                        <div>
                            <label htmlFor="genre" className="font-medium">Genre</label>
                            <input id="genre" placeholder="e.g., Urban Fantasy" value={genre} onChange={(e) => setGenre(e.target.value)} className="w-full p-2 border rounded-md bg-background" />
                        </div>
                        <div>
                            <label htmlFor="characters" className="font-medium">Characters</label>
                            <textarea id="characters" placeholder="Elara, the young librarian with time-stopping powers. Kael, the grumpy talking gargoyle." value={characters} onChange={(e) => setCharacters(e.target.value)} className="w-full min-h-[100px] p-2 border rounded-md bg-background" />
                        </div>
                        {error && <p className="text-destructive text-sm">{error}</p>}
                        <Button onClick={handleGenerate} disabled={isLoading}>
                            {isLoading ? 'Generating...' : 'Generate Outline'}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {outline && (
                <Card>
                    <CardHeader>
                        <CardTitle>{outline.title}</CardTitle>
                        <CardDescription>{outline.logline}</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {outline.scenes.map((scene, index) => (
                                <details key={index} className="p-4 border rounded-lg bg-muted/50">
                                    <summary className="font-semibold cursor-pointer">Scene {scene.scene}: {scene.title}</summary>
                                    <div className="mt-4 pl-4 border-l-2">
                                        <p className="italic text-sm text-muted-foreground">Setting: {scene.setting}</p>
                                        <ul className="list-disc list-inside mt-2 space-y-1">
                                            {scene.events.map((event, i) => <li key={i}>{event}</li>)}
                                        </ul>
                                    </div>
                                </details>
                            ))}
                        </div>
                         {session?.user && (
                            <Button className="mt-4" disabled>Save Outline (Coming Soon)</Button>
                        )}
                    </CardContent>
                </Card>
            )}
        </div>
    );
};

export default WebtoonToolPage;
