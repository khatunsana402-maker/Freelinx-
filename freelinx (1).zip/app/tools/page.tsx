
import React from 'react';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/Card';
import Button from '../../components/ui/Button';

const ArrowRightIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
);


const FreeToolsPage = () => {
  return (
    <div className="space-y-12">
      <section className="text-center">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tighter mb-4">
          AI-Powered Creative Tools
        </h1>
        <p className="max-w-2xl mx-auto text-lg text-muted-foreground">
          Kickstart your creative process with our free AI utilities. Generate script ideas and webtoon outlines in seconds.
        </p>
      </section>

      <section className="max-w-4xl mx-auto">
        <div className="grid md:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>AI Script Generator</CardTitle>
              <CardDescription>Overcome writer's block instantly.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-6">Provide a simple prompt and a genre, and our AI will generate a script scene to get your ideas flowing.</p>
              <Button asChild>
                <Link href="/tools/script">
                  Use Script Generator <ArrowRightIcon className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>AI Webtoon Outliner</CardTitle>
              <CardDescription>Structure your next hit series.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-6">Describe your premise, characters, and genre. Our AI will draft a scene-by-scene outline for your webtoon.</p>
               <Button asChild>
                <Link href="/tools/webtoon">
                   Use Webtoon Outliner <ArrowRightIcon className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default FreeToolsPage;
