import { MetadataRoute } from 'next';
import { NAV_LINKS } from '../constants';

export default function sitemap(): MetadataRoute.Sitemap {
  const siteUrl = process.env.NEXTAUTH_URL || 'http://localhost:3000';

  const staticPages = NAV_LINKS.map(link => ({
    url: `${siteUrl}${link.href}`,
    lastModified: new Date(),
    changeFrequency: 'monthly' as const,
    priority: 0.8,
  }));
  
  // In the future, you could fetch dynamic routes (e.g., creator profiles, projects) here
  // const creators = await prisma.user.findMany({ where: { role: 'CREATOR' }});
  // const creatorPages = creators.map(c => ({ url: `${siteUrl}/creators/${c.id}`, ... }));

  return [
    {
      url: siteUrl,
      lastModified: new Date(),
      changeFrequency: 'weekly',
      priority: 1,
    },
    ...staticPages,
    // ...creatorPages,
  ];
}