

// FIX: Use the edge-compatible Prisma client import.
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import { PrismaClient, UserRole, ProjectStatus, ProposalStatus, OrderStatus } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Start seeding ...');

  // Clear existing data in a safe order
  await prisma.chatMessage.deleteMany();
  await prisma.review.deleteMany();
  await prisma.transaction.deleteMany();
  await prisma.order.deleteMany();
  await prisma.proposal.deleteMany();
  await prisma.project.deleteMany();
  await prisma.category.deleteMany();
  await prisma.script.deleteMany();
  await prisma.webtoonOutline.deleteMany();
  await prisma.account.deleteMany();
  await prisma.session.deleteMany();
  await prisma.user.deleteMany();
  await prisma.settings.deleteMany();
  
  console.log('Cleared existing data.');

  // Seed Settings
  await prisma.settings.create({
    data: {
      key: 'platformCommission',
      value: '0.15', // 15%
    },
  });
  await prisma.settings.create({
    data: {
      key: 'aiToolsFree',
      value: 'true',
    },
  });

  console.log('Settings seeded.');

  // Seed Admin
  const admin = await prisma.user.create({
    data: {
      email: 'admin@demo.com',
      name: 'Admin User',
      role: UserRole.ADMIN,
    },
  });

  // Seed Creators
  const creator1 = await prisma.user.create({
    data: {
      email: 'creator1@demo.com',
      name: 'Creative Artist',
      role: UserRole.CREATOR,
      isVerifiedCreator: true,
      bio: 'A passionate webtoon artist with 5 years of experience creating dynamic characters and worlds.',
      skills: ['webtoon', 'character design', 'illustration', 'manga'],
      portfolioLinks: ['https://www.behance.net/creativeartist', 'https://www.artstation.com/creativeartist'],
      walletBalance: 150.00,
      image: 'https://picsum.photos/seed/creator1/200/200',
    },
  });

  const creator2 = await prisma.user.create({
    data: {
      email: 'creator2@demo.com',
      name: 'Story Weaver',
      role: UserRole.CREATOR,
      isVerifiedCreator: true,
      bio: 'I craft compelling narratives and scripts for various genres, from high-fantasy to grounded sci-fi.',
      skills: ['scriptwriting', 'storyboarding', 'dialogue', 'world-building'],
      portfolioLinks: [],
      walletBalance: 275.50,
      image: 'https://picsum.photos/seed/creator2/200/200',
    },
  });

  // Seed Clients
  const client1 = await prisma.user.create({
    data: {
      email: 'client1@demo.com',
      name: 'Visionary Vistas',
      role: UserRole.CLIENT,
      image: 'https://picsum.photos/seed/client1/200/200',
    },
  });

  const client2 = await prisma.user.create({
    data: {
      email: 'client2@demo.com',
      name: 'Project Propeller',
      role: UserRole.CLIENT,
      image: 'https://picsum.photos/seed/client2/200/200',
    },
  });

  console.log('Users seeded.');

  // Seed Categories
  const webtoonCategory = await prisma.category.create({
    data: {
      name: 'Webtoon Art',
      description: 'Services related to creating webtoon panels, characters, and assets.',
    },
  });

  const scriptCategory = await prisma.category.create({
    data: {
      name: 'Script Writing',
      description: 'Services for writing, editing, and proofreading scripts.',
    },
  });
  
  console.log('Categories seeded.');

  // Seed Projects
  const project1 = await prisma.project.create({
    data: {
      title: 'Fantasy Webtoon Series - "The Crimson Blade"',
      description: 'Looking for an artist to draw the first 3 chapters of a new fantasy webtoon. Style should be similar to Solo Leveling.',
      budget: 1500.00,
      clientId: client1.id,
      categoryId: webtoonCategory.id,
      status: ProjectStatus.OPEN,
    },
  });

  const project2 = await prisma.project.create({
    data: {
      title: 'Short Film Sci-Fi Script',
      description: 'Need a 10-page script for a short film about AI consciousness. Must have a twist ending.',
      budget: 300.00,
      clientId: client2.id,
      categoryId: scriptCategory.id,
      status: ProjectStatus.IN_PROGRESS,
    },
  });
  
  console.log('Projects seeded.');
  
  // Seed a proposal for project 1
  const proposal1 = await prisma.proposal.create({
      data: {
          message: "I'd be a great fit for this! My style is heavily influenced by modern action webtoons. I can deliver the first chapter within 2 weeks.",
          amount: 1400.00,
          projectId: project1.id,
          creatorId: creator1.id,
          status: ProposalStatus.PENDING,
      }
  });

  console.log('Proposals seeded.');

  // Seed an order for project 2 (already in progress)
  const order1 = await prisma.order.create({
      data: {
          totalPrice: 280.00,
          status: OrderStatus.IN_PROGRESS,
          isPaid: true,
          projectId: project2.id,
          clientId: client2.id,
          creatorId: creator2.id,
      }
  });

  console.log('Orders seeded.');

  console.log('Seeding finished.');
}

main()
  .catch((e) => {
    console.error(e);
    throw e;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
