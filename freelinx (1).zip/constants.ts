
export const NAV_LINKS = [
  { name: 'Explore Creators', href: '/explore' },
  { name: 'Services', href: '/services' },
  { name: 'Free Tools', href: '/tools' },
  { name: 'About', href: '/about' },
  { name: 'Contact', href: '/contact' },
];
