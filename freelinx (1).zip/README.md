
# Freelinx

Freelinx is a Fiverr-style marketplace that connects clients with talented creators, supercharged with free AI tools for script and webtoon generation.

## Getting Started

### Prerequisites

- Node.js (v18 or later)
- PostgreSQL (or another database compatible with Prisma)
- An email provider (e.g., Resend, for NextAuth Email provider)
- Google Cloud Platform project for Google OAuth
- Razorpay account for payment processing
- Google AI Studio API Key for Gemini

### Installation

1.  **Clone the repository:**
    ```bash
    git clone <repository-url>
    cd freelinx
    ```

2.  **Install dependencies:**
    ```bash
    npm install
    ```

3.  **Set up the database:**
    - Create a `.env` file by copying `.env.example` (if one exists) or creating a new one.
    - Add your database connection string to the `.env` file.
    ```
    DATABASE_URL="postgresql://user:password@host:port/database"
    ```
    - Push the Prisma schema to your database:
    ```bash
    npx prisma db push
    ```

4.  **Seed the database with initial data:**
    ```bash
    npx prisma db seed
    ```

5.  **Run the development server:**
    ```bash
    npm run dev
    ```
    Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

### Environment Variables

You need to create a `.env` file in the root of your project and add the following variables:

```env
# Prisma
# Example for PostgreSQL
DATABASE_URL="postgresql://<user>:<password>@<host>:<port>/<database>"

# NextAuth
# Generate a secret with `openssl rand -base64 32`
NEXTAUTH_SECRET="..."
NEXTAUTH_URL="http://localhost:3000" # Use your production URL in deployment

# NextAuth Google Provider
GOOGLE_CLIENT_ID="..."
GOOGLE_CLIENT_SECRET="..."

# NextAuth Email Provider (optional, example using Resend)
EMAIL_SERVER_USER="resend"
EMAIL_SERVER_PASSWORD="..." # Your Resend API key
EMAIL_SERVER_HOST="smtp.resend.com"
EMAIL_SERVER_PORT="465"
EMAIL_FROM="onboarding@resend.dev" # Your verified Resend domain email

# Application Settings
ADMIN_EMAIL="your-admin-email@example.com" # The email for the first user to be granted ADMIN role

# Gemini API Key
# Get from Google AI Studio
API_KEY="..."

# Razorpay API Keys (for payments)
RAZORPAY_KEY_ID="..."
RAZORPAY_KEY_SECRET="..."
RAZORPAY_WEBHOOK_SECRET="..." # Secret for verifying webhook requests

# Uploadthing (if used for file uploads in the future)
UPLOADTHING_SECRET="..."
UPLOADTHING_APP_ID="..."
```
