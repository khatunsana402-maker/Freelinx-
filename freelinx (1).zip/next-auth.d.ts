

// FIX: Use the edge-compatible Prisma client import.
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import { UserRole } from '@prisma/client';
import type { DefaultSession } from 'next-auth';
import { JWT } from 'next-auth/jwt';

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      role: UserRole;
    } & DefaultSession['user'];
  }

  // FIX: The 'User' interface augmentation is often not required with JWT strategy
  // and can cause type conflicts. The 'session' interface is what's important
  // for app-side type safety.
  // interface User extends DefaultUser {
  //   role: UserRole;
  // }
}

declare module 'next-auth/jwt' {
  interface JWT {
    role: UserRole;
  }
}
