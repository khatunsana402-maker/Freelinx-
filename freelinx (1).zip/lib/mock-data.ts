
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import { User, UserRole } from '@prisma/client';

export const getMockAdminDashboardData = () => ({
    userCount: 42,
    openProjectsCount: 15,
    completedOrdersCount: 128,
    totalRevenue: { _sum: { amount: 12345.67 } },
    topCreators: [
        { name: 'Mock Creator A', walletBalance: 5800.00 },
        { name: 'Mock Creator B', walletBalance: 4550.50 },
        { name: 'Mock Creator C', walletBalance: 3200.00 },
    ],
    userCounts: {
        [UserRole.CLIENT]: 25,
        [UserRole.CREATOR]: 16,
        [UserRole.ADMIN]: 1,
    }
});

export const getMockUsers = (): User[] => [
    {
        id: 'mock-admin-1',
        name: 'Safe Mode Admin',
        email: 'admin@demo.com',
        emailVerified: new Date(),
        image: null,
        role: UserRole.ADMIN,
        bio: null,
        skills: [],
        portfolioLinks: [],
        walletBalance: 0,
        isVerifiedCreator: false,
        isSuspended: false,
        createdAt: new Date(),
        updatedAt: new Date(),
    },
    {
        id: 'mock-creator-1',
        name: 'Creative Artist (Mock)',
        email: 'creator1@demo.com',
        emailVerified: new Date(),
        image: null,
        role: UserRole.CREATOR,
        bio: 'A mocked webtoon artist.',
        skills: ['webtoon', 'illustration'],
        portfolioLinks: [],
        walletBalance: 150.00,
        isVerifiedCreator: true,
        isSuspended: false,
        createdAt: new Date(),
        updatedAt: new Date(),
    },
    {
        id: 'mock-client-1',
        name: 'Visionary Vistas (Mock)',
        email: 'client1@demo.com',
        emailVerified: new Date(),
        image: null,
        role: UserRole.CLIENT,
        bio: null,
        skills: [],
        portfolioLinks: [],
        walletBalance: 0,
        isVerifiedCreator: false,
        isSuspended: true,
        createdAt: new Date(),
        updatedAt: new Date(),
    },
];
