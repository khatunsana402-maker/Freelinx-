

'use server';

import { revalidatePath } from 'next/cache';
import { prisma } from '../prisma';
// FIX: Use the edge-compatible Prisma client import.
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import { UserRole } from '@prisma/client';

export async function updateUserRole(formData: FormData) {
  const userId = formData.get('userId') as string;
  const role = formData.get('role') as UserRole;

  if (!userId || !role) {
    throw new Error('User ID and role are required.');
  }

  await prisma.user.update({
    where: { id: userId },
    data: { role },
  });

  revalidatePath('/admin/users');
}

export async function toggleUserVerification(formData: FormData) {
    const userId = formData.get('userId') as string;
    if (!userId) throw new Error('User ID is required.');
    
    const user = await prisma.user.findUnique({ where: { id: userId }});
    if (!user) throw new Error('User not found.');

    await prisma.user.update({
        where: { id: userId },
        data: { isVerifiedCreator: !user.isVerifiedCreator },
    });
    revalidatePath('/admin/users');
}

export async function toggleUserSuspension(formData: FormData) {
    const userId = formData.get('userId') as string;
    if (!userId) throw new Error('User ID is required.');

    const user = await prisma.user.findUnique({ where: { id: userId }});
    if (!user) throw new Error('User not found.');

    await prisma.user.update({
        where: { id: userId },
        data: { isSuspended: !user.isSuspended },
    });
    revalidatePath('/admin/users');
}
