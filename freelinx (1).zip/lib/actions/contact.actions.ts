'use server';

// This is a stub for a contact form action.
// In a real application, you would use a service like Resend or Nodemailer
// to send an email to your support address.

export async function sendContactMessage(formData: FormData) {
  const name = formData.get('name') as string;
  const email = formData.get('email') as string;
  const message = formData.get('message') as string;

  if (!name || !email || !message) {
    return { error: 'All fields are required.' };
  }

  // ** TODO: Implement actual email sending logic here **
  // Example using Resend:
  //
  // import { Resend } from 'resend';
  // const resend = new Resend(process.env.RESEND_API_KEY);
  //
  // await resend.emails.send({
  //   from: 'onboarding@resend.dev',
  //   to: process.env.ADMIN_EMAIL!,
  //   subject: `New Contact Message from ${name}`,
  //   reply_to: email,
  //   text: message,
  // });

  console.log('--- New Contact Message ---');
  console.log('Name:', name);
  console.log('Email:', email);
  console.log('Message:', message);
  console.log('---------------------------');

  return { success: true };
}