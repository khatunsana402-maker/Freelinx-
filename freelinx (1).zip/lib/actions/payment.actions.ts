
'use server';
import { razorpay } from '../razorpay';
import { prisma } from '../prisma';

interface CreateOrderParams {
    orderId: string;
    amount: number;
}

export async function createRazorpayOrder(params: CreateOrderParams) {
    const { orderId, amount } = params;
    
    const options = {
        amount: Math.round(amount * 100), // amount in the smallest currency unit (paise)
        currency: "INR",
        receipt: `receipt_order_${orderId}`,
    };

    try {
        const razorpayOrder = await razorpay.orders.create(options);
        
        // Associate the razorpay order ID with our app's order
        await prisma.order.update({
            where: { id: orderId },
            data: { paymentId: razorpayOrder.id },
        });

        return razorpayOrder;

    } catch (error) {
        console.error("Error creating Razorpay order:", error);
        throw new Error("Could not create payment order.");
    }
}
