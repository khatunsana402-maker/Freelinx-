'use client';
import React from 'react';

interface CapturedError {
    error: Error;
    errorInfo: React.ErrorInfo;
    timestamp: Date;
}

export const errors: CapturedError[] = [];

export const addError = (error: Error, errorInfo: React.ErrorInfo) => {
    errors.unshift({ error, errorInfo, timestamp: new Date() });
    // Keep the list to a reasonable size
    if (errors.length > 20) {
        errors.pop();
    }
};

export const clearErrors = () => {
    errors.length = 0;
};
