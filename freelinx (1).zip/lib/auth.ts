
import NextAuth from 'next-auth';
import type { NextAuthConfig, Session } from 'next-auth';
// FIX: Use the edge-compatible Prisma client import.
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import { UserRole } from '@prisma/client';
import { PrismaAdapter } from '@auth/prisma-adapter';
import { prisma } from './prisma';
import GoogleProvider from 'next-auth/providers/google';
import EmailProvider from 'next-auth/providers/email';


const authOptions: NextAuthConfig = {
    adapter: PrismaAdapter(prisma),
    providers: [
      GoogleProvider({
        clientId: process.env.GOOGLE_CLIENT_ID!,
        clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
      }),
      EmailProvider({
        server: process.env.EMAIL_SERVER,
        from: process.env.EMAIL_FROM,
      }),
    ],
    session: {
      strategy: 'jwt',
    },
    callbacks: {
      async session({ session, token }) {
        if (token.sub && session.user) {
          session.user.id = token.sub;
          session.user.role = token.role as UserRole;
        }
        return session;
      },
      async jwt({ token }) {
        if (!token.sub) return token;
  
        const existingUser = await prisma.user.findUnique({
          where: { id: token.sub },
        });
  
        if (!existingUser) return token;
        
        token.role = existingUser.role;
        return token;
      },
    },
    events: {
      async createUser({ user }) {
        if (user.email && user.email === process.env.ADMIN_EMAIL) {
          await prisma.user.update({
            where: { id: user.id! },
            data: { role: UserRole.ADMIN },
          });
        }
      },
    },
    pages: {
      signIn: '/auth/signin',
      verifyRequest: '/auth/verify-request',
      error: '/auth/signin',
    },
};

const mockSession: Session = {
    user: {
      id: 'cl_mock_user_1',
      name: 'Safe Mode Admin',
      email: 'safe@mode.com',
      role: UserRole.ADMIN,
    },
    expires: '2099-01-01T00:00:00.000Z',
};

// Main auth object from NextAuth
const realAuth = NextAuth(authOptions);

// Mock functions for safe mode
const mockAuthFunc = async (): Promise<Session | null> => mockSession;
const mockHandlers = {
    GET: async () => new Response(JSON.stringify(mockSession)),
    POST: async () => new Response(JSON.stringify(mockSession)),
};

// Conditionally export based on environment variable
export const handlers = process.env.NEXT_PUBLIC_PREVIEW_SAFE === 'true' ? mockHandlers : realAuth.handlers;
export const auth = process.env.NEXT_PUBLIC_PREVIEW_SAFE === 'true' ? mockAuthFunc : realAuth.auth;
export const getAuthSession = auth;
export { authOptions };
