// This file is no longer needed for User and UserRole types,
// as we now import them directly from the generated Prisma client
// where they are defined by the schema.
// e.g., import { User, UserRole } from '@prisma/client';

// You can keep this file for other global, non-database types if needed.
