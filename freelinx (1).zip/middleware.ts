

// FIX: Update middleware to NextAuth v5 syntax.
import { auth } from './lib/auth';
import { NextResponse } from 'next/server';
// FIX: Use the edge-compatible Prisma client import.
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import { UserRole } from '@prisma/client';

export default auth((req) => {
    const session = req.auth;
    const { pathname } = req.nextUrl;

    // If the user is not authenticated, the default auth middleware will redirect to the sign-in page.
    // We only need to add custom logic for authenticated users.
    if (session?.user) {
        const userRole = session.user.role as UserRole;

        const protectedRoutes: { path: string, roles: UserRole[] }[] = [
            { path: '/admin', roles: [UserRole.ADMIN] },
            { path: '/creator', roles: [UserRole.CREATOR] },
            { path: '/dashboard', roles: [UserRole.CLIENT, UserRole.CREATOR] }, // Creator can also be a client
        ];

        const protectedRoute = protectedRoutes.find(route => pathname.startsWith(route.path));

        if (protectedRoute && !protectedRoute.roles.includes(userRole)) {
            // If user is logged in but tries to access a page for a different role, redirect to their own dashboard
            let redirectPath = '/';
            if(userRole === UserRole.ADMIN) redirectPath = '/admin';
            if(userRole === UserRole.CREATOR) redirectPath = '/creator';
            if(userRole === UserRole.CLIENT) redirectPath = '/dashboard';
            return NextResponse.redirect(new URL(redirectPath, req.url));
        }

        // Redirect logged-in users from the landing page to their respective dashboards
        if (pathname === '/') {
            let redirectPath = '/';
            if(userRole === UserRole.ADMIN) redirectPath = '/admin';
            if(userRole === UserRole.CREATOR) redirectPath = '/creator';
            if(userRole === UserRole.CLIENT) redirectPath = '/dashboard';
            if (redirectPath !== '/') return NextResponse.redirect(new URL(redirectPath, req.url));
        }
    }
    
    // For all other cases, continue with the request.
    return NextResponse.next();
});

export const config = {
  matcher: [
    '/',
    '/admin/:path*',
    '/creator/:path*',
    '/dashboard/:path*',
    '/projects/:path*',
    '/orders/:path*',
  ],
};
