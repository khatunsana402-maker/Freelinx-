
'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import React from 'react';

const sidebarLinks = [
  { name: 'Dashboard', href: '/admin' },
  { name: 'Users', href: '/admin/users' },
  { name: 'Projects', href: '/admin/projects' },
  { name: 'Proposals', href: '/admin/proposals' },
  { name: 'Orders', href: '/admin/orders' },
  { name: 'Categories', href: '/admin/categories' },
  { name: 'Settings', href: '/admin/settings' },
];

const AdminSidebar = () => {
  const pathname = usePathname();
  return (
    <aside className="w-64 flex-shrink-0 border-r bg-secondary/50 hidden md:block">
      <div className="h-full flex flex-col">
        <div className="p-4 border-b">
          <h2 className="text-lg font-semibold tracking-tight">Admin Panel</h2>
        </div>
        <nav className="flex flex-col p-2 space-y-1">
          {sidebarLinks.map(link => (
            <Link
              key={link.href}
              href={link.href}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                pathname === link.href
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
              }`}
            >
              {link.name}
            </Link>
          ))}
        </nav>
      </div>
    </aside>
  );
};

export default AdminSidebar;
