

'use client';

import React, { useState } from 'react';
import Script from 'next/script';
import Button from '../ui/Button';
// FIX: Import 'Order' as a type since it's only used for type annotation.
// FIX: Use the edge-compatible Prisma client import.
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import type { Order } from '@prisma/client';
import { createRazorpayOrder } from '../../lib/actions/payment.actions';
import { useRouter } from 'next/navigation';

interface PaymentButtonProps {
    order: Order;
}

declare global {
    interface Window {
        Razorpay: any;
    }
}

const PaymentButton: React.FC<PaymentButtonProps> = ({ order }) => {
    const [loading, setLoading] = useState(false);
    const router = useRouter();

    const handlePayment = async () => {
        setLoading(true);
        try {
            const razorpayOrder = await createRazorpayOrder({ orderId: order.id, amount: order.totalPrice });
            
            if (!razorpayOrder.id) {
                throw new Error("Failed to create Razorpay order.");
            }

            const options = {
                key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
                amount: razorpayOrder.amount,
                currency: razorpayOrder.currency,
                name: "Freelinx",
                description: `Payment for Order #${order.id.substring(0, 8)}`,
                order_id: razorpayOrder.id,
                handler: function (response: any) {
                    // This is where you would ideally verify the payment on your server
                    // But for this flow, we rely on the webhook. 
                    // We just redirect the user to a success page or refresh.
                    alert("Payment Successful! Your order is being processed.");
                    router.refresh();
                },
                prefill: {
                    // You can prefill user data here if available
                    // name: session.user.name,
                    // email: session.user.email,
                },
                theme: {
                    color: "#3399cc"
                }
            };
            const rzp = new window.Razorpay(options);
            rzp.open();

        } catch (error) {
            console.error("Payment Error:", error);
            alert("Payment failed. Please try again.");
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <Script
                id="razorpay-checkout-js"
                src="https://checkout.razorpay.com/v1/checkout.js"
            />
            <Button onClick={handlePayment} disabled={loading}>
                {loading ? 'Processing...' : `Pay with Razorpay (₹${order.totalPrice.toFixed(2)})`}
            </Button>
        </>
    );
};

export default PaymentButton;
