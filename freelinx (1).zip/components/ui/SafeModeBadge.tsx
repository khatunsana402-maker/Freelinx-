'use client';

export function SafeModeBadge() {
    if (process.env.NEXT_PUBLIC_PREVIEW_SAFE !== 'true') {
        return null;
    }

    return (
        <div className="fixed bottom-4 left-4 z-50 bg-yellow-400 text-black px-3 py-1 rounded-full text-xs font-bold shadow-lg animate-pulse">
            Preview-Safe ON
        </div>
    );
}
