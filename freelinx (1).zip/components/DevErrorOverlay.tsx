'use client';

import React, { Component, ErrorInfo, ReactNode } from 'react';
import { useToast } from './ui/use-toast';
import { addError } from '../lib/errorStore';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
}

// A wrapper component is needed to use the `useToast` hook in a class component.
function withToast(ComponentToWrap: any) {  
  return function WrappedComponent(props: any) {
    const { toast } = useToast();
    return <ComponentToWrap {...props} toast={toast} />;
  }
}

class ErrorBoundary extends Component<Props & { toast: any }, State> {
  public state: State = {
    hasError: false,
  };

  public static getDerivedStateFromError(_: Error): State {
    return { hasError: true };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    if (process.env.NODE_ENV === 'development') {
        console.error("Uncaught error:", error, errorInfo);
        this.props.toast({
            variant: "destructive",
            title: "Client-side Error",
            duration: 10000,
            description: (
              <pre className="mt-2 w-[340px] whitespace-pre-wrap rounded-md bg-slate-950 p-4">
                <code className="text-white text-xs">{error.message}\n\n{errorInfo.componentStack}</code>
              </pre>
            ),
        });
        addError(error, errorInfo);
        this.setState({ hasError: false }); // Reset state to allow app to continue
    }
  }

  public render() {
    return this.props.children;
  }
}

const DevErrorOverlay = process.env.NODE_ENV === 'development'
  ? withToast(ErrorBoundary)
  : ({ children }: Props) => <>{children}</>;


export default DevErrorOverlay;
