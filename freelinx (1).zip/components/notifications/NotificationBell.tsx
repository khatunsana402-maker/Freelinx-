
'use client';
import React, { useState } from 'react';
import Button from '../ui/Button';

const BellIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
);

const mockNotifications = [
    { id: 1, message: "You received a new proposal for 'Fantasy Webtoon Series'.", isRead: false, link: '#' },
    { id: 2, message: "Payment of ₹300.00 for 'Short Film Script' was successful.", isRead: false, link: '#' },
    { id: 3, message: "Creative Artist sent you a new message.", isRead: true, link: '#' },
];

const NotificationBell: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const unreadCount = mockNotifications.filter(n => !n.isRead).length;

    return (
        <div className="relative">
            <Button variant="ghost" size="icon" onClick={() => setIsOpen(!isOpen)}>
                <BellIcon className="h-5 w-5" />
                {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 flex h-4 w-4">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-4 w-4 bg-primary text-xs text-primary-foreground items-center justify-center">{unreadCount}</span>
                    </span>
                )}
                <span className="sr-only">View notifications</span>
            </Button>
            {isOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-popover border rounded-md shadow-lg z-50">
                    <div className="p-3 border-b font-semibold">Notifications</div>
                    <ul className="py-1">
                        {mockNotifications.map(notification => (
                             <li key={notification.id} className={`px-3 py-2 text-sm hover:bg-accent ${!notification.isRead ? 'font-medium' : 'text-muted-foreground'}`}>
                                <a href={notification.link} className="block">{notification.message}</a>
                             </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default NotificationBell;
