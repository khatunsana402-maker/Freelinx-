import React from 'react';
import Link from 'next/link';

const GithubIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"/></svg>
);
const TwitterIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M22 4s-.7 2.1-2 3.4c1.6 1.4 3.3 4.4 3.3 4.4s-1.4 1.4-2.1 2c-1.2 1-3.2 2.6-3.2 2.6s-1.2-1.1-2.6-2.6c-2.3-2.5-3.2-3.8-3.2-3.8s-1.1 1.2-2.6 2.6c-2.4 2.5-3.2 3.8-3.2 3.8s-1.2-1.1-2.1-2c-.8-1-2.1-2-2.1-2s1.6-3 3.3-4.4C2.7 6.1 2 4 2 4s2.1.7 3.4 2c1.4-1.6 4.4-3.3 4.4-3.3s1.1 1.2 2.6 3.2c2.4 2.5 3.8 3.2 3.8 3.2s1.1-1.2 2.6-2.6c1.3-.9 2.6-.9 2.6-.9Z"/></svg>
);
const FreelinxLogo = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <defs>
      <linearGradient id="logoGradientFooter" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#4f46e5" />
        <stop offset="100%" stopColor="#9333ea" />
      </linearGradient>
    </defs>
    <path d="M12.55 2.22a.5.5 0 0 0-.55-.22L4 5v14l8.55-3.22a.5.5 0 0 0 .45-.48V2.7a.5.5 0 0 0 0-.48zM12 15.3l-7.5 2.82V5.88L12 3.06v12.24z" fill="url(#logoGradientFooter)"/>
    <path d="M13 3v11.83l7.5 2.83V5.83L13 3zm6.5 13.97L14 13.64V4.03l5.5 2.06v10.88z" fill="url(#logoGradientFooter)" opacity="0.75"/>
    <path d="M12.5 10.5l-2-1.5 2-1.5v-2l-3.5 2.5 3.5 2.5v-1z" fill="currentColor"/>
  </svg>
);


const footerLinks = {
  navigation: [
    { name: 'Explore Creators', href: '/explore' },
    { name: 'Services', href: '/services' },
    { name: 'Free Tools', href: '/tools' },
  ],
  company: [
    { name: 'About', href: '/about' },
    { name: 'Contact', href: '/contact' },
    { name: 'Join Community', href: '#' },
  ],
  legal: [
    { name: 'Terms of Service', href: '/terms' },
    { name: 'Privacy Policy', href: '/privacy' },
  ]
};

const Footer: React.FC = () => {
  return (
    <footer className="border-t border-border/40 bg-background">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center space-x-2">
               <FreelinxLogo />
              <span className="font-bold text-lg">Freelinx</span>
            </Link>
            <p className="mt-2 text-muted-foreground text-sm">
              Your one-stop marketplace for creative talent and AI tools.
            </p>
          </div>
          <div className="md:col-span-3 grid grid-cols-2 sm:grid-cols-3 gap-8">
            <div>
              <h3 className="font-semibold tracking-wider text-sm uppercase">Navigation</h3>
              <ul className="mt-4 space-y-2">
                {footerLinks.navigation.map((link) => (
                  <li key={link.name}>
                    <Link href={link.href} className="text-muted-foreground hover:text-primary text-sm">
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="font-semibold tracking-wider text-sm uppercase">Company</h3>
               <ul className="mt-4 space-y-2">
                {footerLinks.company.map((link) => (
                  <li key={link.name}>
                    <Link href={link.href} className="text-muted-foreground hover:text-primary text-sm">
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
             <div>
              <h3 className="font-semibold tracking-wider text-sm uppercase">Legal</h3>
              <ul className="mt-4 space-y-2">
                {footerLinks.legal.map((link) => (
                  <li key={link.name}>
                    <Link href={link.href} className="text-muted-foreground hover:text-primary text-sm">
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-border/40 flex flex-col sm:flex-row justify-between items-center">
          <p className="text-muted-foreground text-sm">&copy; {new Date().getFullYear()} Freelinx, Inc. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 sm:mt-0">
            <a href="#" className="text-muted-foreground hover:text-primary"><TwitterIcon /></a>
            <a href="#" className="text-muted-foreground hover:text-primary"><GithubIcon /></a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;