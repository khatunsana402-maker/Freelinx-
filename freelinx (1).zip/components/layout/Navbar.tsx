
'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { NAV_LINKS } from '../../constants';
import { useSession, signIn, signOut } from 'next-auth/react';
import Button from '../ui/Button';
import ThemeToggle from '../ui/ThemeToggle';
import NotificationBell from '../notifications/NotificationBell';
// FIX: Use the edge-compatible Prisma client import.
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import { UserRole } from '@prisma/client';

const MenuIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><line x1="4" x2="20" y1="12" y2="12" /><line x1="4" x2="20" y1="6" y2="6" /><line x1="4" x2="20" y1="18" y2="18" /></svg>
);

const XIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M18 6 6 18" /><path d="m6 6 12 12" /></svg>
);

const FreelinxLogo = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <defs>
      <linearGradient id="logoGradient" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#4f46e5" />
        <stop offset="100%" stopColor="#9333ea" />
      </linearGradient>
    </defs>
    {/* This is the F-spark icon for mobile */}
    <path className="block md:hidden" d="M13 3v11.83l7.5 2.83V5.83L13 3zm6.5 13.97L14 13.64V4.03l5.5 2.06v10.88zM12.5 10.5l-2-1.5 2-1.5v-2l-3.5 2.5 3.5 2.5v-1z" fill="url(#logoGradient)"/>
    {/* This is the full logo for desktop */}
    <g className="hidden md:block">
      <path d="M12.55 2.22a.5.5 0 0 0-.55-.22L4 5v14l8.55-3.22a.5.5 0 0 0 .45-.48V2.7a.5.5 0 0 0 0-.48zM12 15.3l-7.5 2.82V5.88L12 3.06v12.24z" fill="url(#logoGradient)"/>
      <path d="M13 3v11.83l7.5 2.83V5.83L13 3zm6.5 13.97L14 13.64V4.03l5.5 2.06v10.88z" fill="url(#logoGradient)" opacity="0.75"/>
      <path d="M12.5 10.5l-2-1.5 2-1.5v-2l-3.5 2.5 3.5 2.5v-1z" fill="currentColor"/>
    </g>
  </svg>
);


const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { data: session } = useSession();
  const user = session?.user;
  const pathname = usePathname();

  const getDashboardPath = () => {
    switch(user?.role) {
      case UserRole.ADMIN: return '/admin';
      case UserRole.CREATOR: return '/creator';
      case UserRole.CLIENT: return '/dashboard';
      default: return '/';
    }
  };

  const navLinkClasses = (href: string) => `transition-colors hover:text-primary ${pathname === href ? 'text-primary font-semibold' : 'text-muted-foreground'}`;

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center space-x-2">
          <FreelinxLogo />
          <span className="font-bold text-lg hidden md:inline-block">Freelinx</span>
        </Link>

        <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
          {NAV_LINKS.map((link) => (
            <Link key={link.name} href={link.href} className={navLinkClasses(link.href)}>
              {link.name}
            </Link>
          ))}
        </nav>

        <div className="flex items-center space-x-1 md:space-x-2">
          <ThemeToggle />
          {user && <NotificationBell />}
          <div className="hidden md:flex items-center space-x-2">
            {!user ? (
              <>
                <Button variant="ghost" onClick={() => signIn()}>Login</Button>
                <Button onClick={() => signIn()}>Sign Up</Button>
              </>
            ) : (
              <>
                <Button variant="ghost" href={getDashboardPath()}>Dashboard</Button>
                <Button onClick={() => signOut()}>Logout</Button>
              </>
            )}
          </div>
          <div className="md:hidden">
            <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <XIcon /> : <MenuIcon />}
              <span className="sr-only">Toggle menu</span>
            </Button>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden border-t border-border/40">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col space-y-4">
            {NAV_LINKS.map((link) => (
              <Link key={link.name} href={link.href} className={navLinkClasses(link.href)} onClick={() => setIsMenuOpen(false)}>
                {link.name}
              </Link>
            ))}
            <div className="border-t border-border/40 pt-4">
              {!user ? (
                <div className='flex items-center space-x-2'>
                  <Button variant="ghost" className='w-full' onClick={() => { signIn(); setIsMenuOpen(false); }}>Login</Button>
                  <Button className='w-full' onClick={() => { signIn(); setIsMenuOpen(false); }}>Sign Up</Button>
                </div>
              ) : (
                <div className='flex flex-col space-y-2'>
                  <Button variant="ghost" href={getDashboardPath()} onClick={() => setIsMenuOpen(false)}>Dashboard</Button>
                  <Button onClick={() => { signOut(); setIsMenuOpen(false); }}>Logout</Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
