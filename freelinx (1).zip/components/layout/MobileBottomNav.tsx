
'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { useVibrate } from '../../hooks/useVibrate';
// FIX: Import UserRole from prisma client to use in switch statement.
// @ts-expect-error This error is due to a missing `prisma generate` step in the environment.
import { UserRole } from '@prisma/client';

const HomeIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
);
const CompassIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></svg>
);
const BotIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg>
);
const UserIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
);

const MobileBottomNav: React.FC = () => {
    const pathname = usePathname();
    const { data: session } = useSession();
    const vibrate = useVibrate();

    const getDashboardPath = () => {
        if (!session?.user) return '/api/auth/signin';
        switch (session.user.role) {
            case UserRole.ADMIN: return '/admin';
            case UserRole.CREATOR: return '/creator';
            case UserRole.CLIENT: return '/dashboard';
            default: return '/dashboard';
        }
    };
    
    const navLinks = [
        { href: '/', icon: HomeIcon, label: 'Home' },
        { href: '/explore', icon: CompassIcon, label: 'Explore' },
        { href: '/tools/chat', icon: BotIcon, label: 'AI Chat' },
        { href: getDashboardPath(), icon: UserIcon, label: session?.user ? 'Dashboard' : 'Login' },
    ];
    
    // The AI Chat link is a special case to open the chatbot drawer, handled globally.
    // Here, we prevent default navigation for it.
    const handleChatClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        // The chatbot component listens for a custom event to open itself
        window.dispatchEvent(new CustomEvent('toggle-chatbot'));
        vibrate();
    };

    return (
        <div className="mobile-nav">
            <div className="mobile-nav-content">
                {navLinks.map(({ href, icon: Icon, label }) => {
                    const isActive = (href === '/' && pathname === '/') || (href !== '/' && pathname.startsWith(href) && href !== '/tools/chat');
                    const isChat = href === '/tools/chat';
                    const linkClasses = `mobile-nav-link ${isActive ? 'text-primary' : 'text-muted-foreground'}`;
                    
                    const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
                        if (isChat) {
                            handleChatClick(e);
                        } else {
                            vibrate();
                        }
                    };

                    return (
                        <Link key={label} href={href} className={linkClasses} onClick={handleClick}>
                            <Icon className="h-6 w-6 mb-1" />
                            <span>{label}</span>
                        </Link>
                    );
                })}
            </div>
        </div>
    );
};

export default MobileBottomNav;
